<?php

class Student implements Countable
{
    public function count()
    {
        return 3;
    }
}

$obj = new Student;
echo count($obj);