<?php
require_once 'vendor/autoload.php';

use App\Application as Di;

// 注册服务
Di::bind('car', function() {
    return TrafficToolFactory::createTool('car');
});
// 使用服务
$service = Di::make('car');
