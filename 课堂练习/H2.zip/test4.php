<?php

// Reflection::export(new ReflectionExtension('Reflection'));
// 
// ReflectionFunction类
function testAdd($a, $b)
{
    return $a + $b;
}

$rf = new ReflectionFunction('testAdd');
$p = $rf->getParameters();
// var_dump($p);
// echo $rf->invoke(3, 4);

class Person
{
    protected $_name;
    protected $_age;

    public function getName() {}
    public function getAge() {}
    public function __construct() {}
}

$rf = new ReflectionClass('Person');
$methods = $rf->getMethods();
// var_dump($methods);

$obj = $rf->newInstance();
var_dump($obj);