<?php
// 加载Composer自动加载文件
require_once 'vendor/autoload.php';

// 第2种策略：构造一个 工厂，专门用来生产 交通工具
$traveller = new App\Traveller();
$traveller->travel();

