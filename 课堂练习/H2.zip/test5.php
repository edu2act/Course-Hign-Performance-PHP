<?php
// 加载Composer自动加载文件
require_once 'vendor/autoload.php';

// 测试
// $walker = new App\Walk();
// $walker->go();
// $traveller = new App\Traveller();
// 问题：调用者需要依赖被调用者，直接在调用者类中构造被调用者实例对象
// 策略原理：控制反转（被调用者的创建，不再由调用者决定，而由外部容器决定）
// 依赖倒置：Dependcy Inversion
// 控制反转：Inverse of Control
// 新的问题
// 问题1：类如何限制必须实现 指定接口？
// 问题2：如何实现延迟加载？
$traveller = new App\Traveller(new App\Car());
$traveller->travel();

// 第2种策略：构造一个 工厂，专门用来生产 交通工具