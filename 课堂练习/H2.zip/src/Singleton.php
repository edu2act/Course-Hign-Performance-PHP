<?php
namespace App;

class Singleton
{
    // 当前类的实例对象
    protected static $_instance = null;
    // public $name = 'test1';

    // 构造方法不是public，在类外不能被访问
    // 故不能使用 new 创建对象
    protected function __construct()
    {

    }

    public static function getInstance()
    {
        if (null == static::$_instance) {
            static::$_instance = new static();
        }
        return static::$_instance;
    }
}

// // $obj = new Singleton();
// $obj = Singleton::getInstance();
// $obj->name = 'test2';
// $obj2 = Singleton::getInstance();
// echo $obj2->name;
