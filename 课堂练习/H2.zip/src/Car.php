<?php
namespace App;

class Car implements TrafficTool
{
    public function go()
    {
        echo 'driver car to Tibet';
    }
}