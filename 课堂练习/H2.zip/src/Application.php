<?php
namespace App;

class Application
{
    protected static $_services = [];

    public static function bind($name, $definition)
    {
        static::$_services[$name] = $definition;
    }

    public static function make($name)
    {
        $service = static::$_services[$name];
        if ($sevice instanceof \Closure) {
            return $service;
        }
        return false;
    }
}