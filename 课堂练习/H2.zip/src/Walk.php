<?php
namespace App;

class Walk implements TrafficTool
{
    public function go() 
    {
        echo 'walk to Tibet';
    }
}