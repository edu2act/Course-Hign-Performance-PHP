<?php
namespace App;

class TrafficToolFactory
{
    public static function createTool($toolType)
    {
        switch ($toolType) {
            case 'car':
                return new Car();
            case 'walk':
                return new Walk();
            default:
                # code...
                break;
        }
    }
}