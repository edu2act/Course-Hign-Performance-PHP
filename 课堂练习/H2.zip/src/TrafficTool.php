<?php
namespace App;

interface TrafficTool
{
    public function go();
}