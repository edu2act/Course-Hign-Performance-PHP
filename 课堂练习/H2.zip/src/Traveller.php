<?php
namespace App;

class Traveller
{
    protected $_name = 'xiao ming'; 
    protected $_trafficTool = null;  

    public function __construct(TrafficTool $tool)
    // public function __construct($toolType = 'walk')
    {
        $this->_name = 'xiao li ';
        // $this->_trafficTool = new Car();
        $this->_trafficTool = $tool;
        // $this->_trafficTool = TrafficToolFactory::createTool($toolType);
    }

    public function travel()
    {
        echo $this->_name;
        $this->_trafficTool->go();
    }
}