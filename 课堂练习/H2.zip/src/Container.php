<?php
namespace App;

class Container extends Singleton
{
    protected $_tools = [];

    public function __call($method, $params)
    {
        return $this->$method(...$params);
    }

    public static function __callStatic($method, $params)
    {
        $instance = new static();
        $instance->$method(...$params);
    }

    protected function set($name, $definition)
    {
        $this->_tools[$name] = $definition;
    }

    protected function get($name)
    {
        $tool = $this->_tools[$name];
        if ($tool instanceof \Closure) {
            return call_user_func($tool);
        } /*else if ($tool instanceof TrafficTool) {
            return $tool;
        }*/
        return false;
    }
}