<?php
// 加载Composer自动加载文件
require_once 'vendor/autoload.php';

// 第3种策略：使用IOC容器
// $ioc = new App\Container();
$ioc = App\Container::getInstance();
// 向容器中添加内容
$ioc->set('car', function() {
    return App\TrafficToolFactory::createTool('car');
});
$ioc->set('walk', function() {
    return App\TrafficToolFactory::createTool('walk');
});
// $ioc = new App\Container;
// 把被调用者 注入到 调用者中
$traveller = new App\Traveller($ioc->get('car'));
$traveller->travel();

// 依赖注入：Dependcy Injection