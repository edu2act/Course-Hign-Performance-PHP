<?php

$obj = new SplFileObject('test3.php');
// var_dump($obj);
foreach ($obj as $line) {
    echo $line;
}