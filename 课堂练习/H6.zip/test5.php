<?php
// 获取所有数据
// 普通方法
$sql = "select * from news";
$results = mysqli_query($sql);
while ($row = mysqli_fetch_assoc($results)) {
    // 处理$row
}

// 改进yield方式
function getAllRecords()
{
    $sql = "select * from news";
    $results = mysqli_query($sql);
    while ($row = mysqli_fetch_assoc($results)) {
        yield $row;
    }
}
$rs = getAllRecords();
foreach ($rs as $value) {
    // $value
}