<?php
// 匿名类
$obj = new class {
    public $name = 'test';
    public function getName() 
    {
        return $this->name;
    }
};
// var_dump($obj);
// echo $obj->getName();
class Outer
{
    private $_name = 'outer';
    public function test1()
    {
        return new class($this->_name) {
            private $_trueName;
            public function __construct($trueName)
            {
                $this->_trueName = $trueName;
            }
            public function test2()
            {
                return $this->_trueName;
            }
        };
    }
}
$p1 = new Outer;
$p2 = $p1->test1();
echo $p2->test2();