<?php
function xrange($start, $end)
{
    for ($i=$start; $i <= $end; $i++) { 
        yield $i;
    }
}

// 普通数组形式
echo memory_get_usage(), "\n";
$arr = range(1, 10000);
// $arr = xrange(1, 10000);
// var_dump($arr);exit;
foreach ($arr as $key => $value) {
    // 
}
echo memory_get_usage(), "\n";
