<?php
function xrange($start, $end)
{
    for ($i=$start; $i <= $end; $i++) { 
        yield $i;
    }
}

// 普通数组形式
echo time(), "\n";
// $arr = range(1, 1000000);
$arr = xrange(1, 1000000);
foreach ($arr as $key => $value) {
    // 
}
echo time(), "\n";
