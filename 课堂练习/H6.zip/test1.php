<?php
// 强制类型声明为开启状态
// 当类型不一致时，程序报错
declare(strict_types=1);

// before php7
function test(array $arr)
{
    foreach ($arr as $value) {
        // ……
    }
}

interface PayInterface
{
    public function pay();
}
class Alipay implements PayInterface
{
    public function pay()
    {
        echo 'alipay';
    }
}

function test2(PayInterface $payMethod)
{
    $payMethod->pay();
}
// 类的实例对象 is instanceof 接口名
// test2(new Alipay());

// after php7
function test3(int $a, int $b)
{
    return $a + $b;
}
echo test3(3.14, 5);