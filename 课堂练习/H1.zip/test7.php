<?php
class Person
{
    public $name;
    public $age;
    public $birthday;

    public function getName() {
        return $this->name;
    }
    public function getAge() {
        return $this->age;
    }

    public function gettttt() {
        echo 'llkl';
    }
}

echo memory_get_usage(), "\n";    // 获取当前分配的内存大小
$obj = new Person();
echo memory_get_usage(), "\n";    // 获取当前分配的内存大小
$obj2 = new Person();
echo memory_get_usage(), "\n";    
$obj3 = new Person();
echo memory_get_usage(), "\n"; 