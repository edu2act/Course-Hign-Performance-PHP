<?php

namespace App;  // 命名空间必须是有效代码的第1行
require_once 'Birthday.php';

class Person 
{
    // 属性
    // 公有属性
    public $name;
    // 非公有属性（建议名称前加下划线）
    public $age;
    public $birthday;

    public function __construct($name, $age, $birthday) 
    {
        $this->name = $name;
        $this->age = $age;
        $this->birthday = $birthday;
        // 如果当前文件已经定义命名空间，
        // 使用其它命名空间中的类时，
        // 必须使用类全名，或者先use再使用
        // 根命名为 \，如 \Exception
        // $exception = new \Exception();
    }

    public function __clone() {
        $this->birthday = clone $this->birthday;
    }

    /**
     * 测试结果是否正确
     * @return [type] [description]
     */
    public static function testResult() 
    {

    }

    final public function testFinal() 
    {

    }

    protected function _getConnection() 
    {

    }

    /**
     * 方法的作用概述
     * @param  string  $name 用户姓名
     * @param  boolean $flag [description]
     * @return array|boolean        若操作成功，返回数组；否则返回false
     */
    public function getRealName($name, $flag = false) 
    {

    }
}

// sublime 中文档注释插件：DocBlockr