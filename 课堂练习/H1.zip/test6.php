<?php
class Person
{
    public $name;
    public $age;

    public function __tostring() 
    {
        return serialize($this);
    }
}

$obj = new Person();
$obj->name = 'test';
$obj->age = 18;

echo $obj;exit;

$str = serialize($obj);

// $p = unserialize($str);
// print_r($p);
// echo $str;
echo "\n";