<?php
require_once 'Birthday.php';
require_once 'Person.php';

// test
$b1 = new App\Birthday(1999, 1, 1);

$p1 = new App\Person('test', 18, $b1);
// print_r($p1);
$p2 = clone $p1;
$p2->birthday->year = 2005;
print_r($p1);