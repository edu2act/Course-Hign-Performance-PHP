<?php
namespace App;

class Birthday
{
    public $year;
    public $month;
    public $day;

    public function __construct($y, $m, $d) {
        $this->year = $y;
        $this->month = $m;
        $this->day = $d;
    }
}