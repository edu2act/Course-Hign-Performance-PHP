<?php
// 代码规范
$str = "";  // 字符串，变量名最好有意义
$num1 = 1;
$num2 = 2;
$result = $num1 + $num2;    // 运算符左右有空格

// 语句和关键字
if ($result == 0) {

}
for ($i = 0; $i < 5; $i++) { 
    # code...
}

// 函数
function testAdd($num1, $num2) 
{

}

// 常量
const PI = 3.14;
const STUDENT_NUMBER = 3;

// 文件末尾，不加 结束符号
// PSR-1 和 PSR-2
// 