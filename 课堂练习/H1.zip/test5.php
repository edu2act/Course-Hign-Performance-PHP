<?php
trait A
{
    public function smallTalk()
    {
        echo 'a';
    }
    public function bigTalk()
    {
        echo 'A';
    }
}
trait B
{
    public function smallTalk()
    {
        echo 'b';
    }
    public function bigTalk()
    {
        echo 'B';
    }
}

class Test
{
    use A, B {
        A::smallTalk insteadof B;
        B::bigTalk insteadof A;
        B::smallTalk as talk;
    }
}

$obj = new Test;
$obj->smallTalk();
echo "\n";
$obj->bigTalk();
echo "\n";
$obj->talk();