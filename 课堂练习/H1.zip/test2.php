<?php
require_once 'Person.php';

// 测试Person类
$obj = new App\Person('test', 18);
// $obj = new Exception();
var_dump($obj);