<?php
// 先讨论继承
class A 
{
    private $_name = 'test';
}
class B extends A 
{
    public function test()
    {
        echo $this->_name;
    }
}

$obj = new B();
// $obj->test();
// 
// =====================
// Trait
trait Ttrait 
{
    private $_name = 'test';
    abstract public function ttt();
    public function testName() 
    {
        echo $this->_name;
    }
}
trait Ttrait2
{
    public function testHaha() {
        echo 'haha !';
    }
}
class C
{
    // 使用Trait，相当于把 Trait的内容在此展开
    use Ttrait;
    use Ttrait2;
    public function ttt() {
        
    }
}

$o = new C;
$o->testHaha();
