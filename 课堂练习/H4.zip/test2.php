<?php
echo date('Y-m-d H:i:s'), "\n";   // 格式化时间
function opreateArray($arr) 
{
    foreach ($arr as $val) {
        $tmp = $val;
    }
}
$arr = array_fill(0, 1000000, 3);
opreateArray($arr);
echo date('Y-m-d H:i:s'), "\n";   // 格式化时间
