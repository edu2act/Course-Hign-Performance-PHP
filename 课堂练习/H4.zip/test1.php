<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>response</title>
</head>
<body>
    <?php
setcookie('name', 'test');
echo php_sapi_name(); ?>
</body>
</html>
