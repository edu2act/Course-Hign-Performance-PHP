<?php
function printDir($dirName, $tabNumber = 0)
{
    $dir = new DirectoryIterator($dirName);
    foreach ($dir as $key => $file) {
        if (!$file->isDot()) {
            for ($i=0; $i < $tabNumber; $i++) { 
                echo "\t";
            }
            echo $file->getFileName(), "\n";
            if ($file->isDir()) {
                printDir($file->getRealPath(), $tabNumber+1);
            }
        }
    }
}

printDir('.');