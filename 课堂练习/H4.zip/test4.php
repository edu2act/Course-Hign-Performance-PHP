<?php
class Db
{
    protected function getCharset()
    {
        return 'utf-8';
    }

    protected function add($x, $y)
    {
        return $x + $y;
    }

    public function __call($name, $arguments)
    {
        if (method_exists($this, $name)) {
            return $this->$name(...$arguments);
        }
    }

    public static function __callStatic($name, $arguments)
    {
        $obj = new static();
        return $obj->$name(...$arguments);
    }
}

$obj = new Db();
// echo $obj->getCharset();
// echo $obj->add(3, 4);
echo Db::add(3, 4);
