<?php

use Illuminate\Container\Container;
use Illuminate\Database\Capsule\Manager as Capsule;

/**
 * @name Bootstrap
 * @author lsl\lsl
 * @desc 所有在Bootstrap类中, 以_init开头的方法, 都会被Yaf调用,
 * @see http://www.php.net/manual/en/class.yaf-bootstrap-abstract.php
 * 这些方法, 都接受一个参数:Yaf_Dispatcher $dispatcher
 * 调用的次序, 和申明的次序相同
 */
class Bootstrap extends Yaf_Bootstrap_Abstract{

    public function _initConfig() {
		//把配置保存起来
		$arrConfig = Yaf_Application::app()->getConfig();
		Yaf_Registry::set('config', $arrConfig);
	}

	public function _initPlugin(Yaf_Dispatcher $dispatcher) {
		//注册一个插件
		$objSamplePlugin = new SamplePlugin();
		$dispatcher->registerPlugin($objSamplePlugin);
	}

	public function _initRoute(Yaf_Dispatcher $dispatcher) {
		//在这里注册自己的路由协议,默认使用简单路由
	}
	
	public function _initView(Yaf_Dispatcher $dispatcher){
		//在这里注册自己的view控制器，例如smarty,firekylin
	}

	/**
	 * 自动加载Laravel数据库连接
	 */
	public function _initDatabase()
	{
		// 数据库配置项
		$config = Yaf_Application::app()->getConfig()->toArray();
		// dd($config);
		$database = $config['database'];
		// $database = [
		//     'driver' => 'mysql',
		//     'host' => '127.0.0.1',
		//     'database' => 'cms',
		//     'username' => 'root',
		//     'password' => 'root',
		//     'charset' => 'utf8',
		//     'collation' => 'utf8_general_ci',
		// ];

		$capsule = new Capsule;

		// 创建链接
		$capsule->addConnection($database);

		// 设置全局静态可访问DB
		$capsule->setAsGlobal();

		// 启动Eloquent
		$capsule->bootEloquent();
	}
}
