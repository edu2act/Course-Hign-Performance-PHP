<?php
use Illuminate\Database\Capsule\Manager as DB;

class MemberController extends Yaf_Controller_Abstract
{
    public function indexAction()
    {
        // 获取请求对象
        $request = $this->getRequest();
        // 获取请求参数
        $name = $request->get('name');
        // 先获取视图对象
        $view = $this->getView();
        // 向视图文件赋值
        $view->assign('name', $name);
    }

    public function testAction()
    {
        // 测试数据库连接
        // $obj = DB::table('members');
        // dd($obj);
        // 获取所有数据
        // $results = DB::table('members')->get();
        // dd($results);
        // 使用Eloquent ORM
        dd(MemberModel::all());
    }
}