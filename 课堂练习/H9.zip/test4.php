<?php
// 修改session驱动
ini_set('session.save_handler', 'redis');
ini_set('session.save_path', 'tcp://127.0.0.1:6379');
// var_dump(session_save_path());
session_start();
var_dump($_SESSION);