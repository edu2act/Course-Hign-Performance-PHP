<?php
// 修改session驱动
ini_set('session.save_handler', 'redis');
ini_set('session.save_path', 'tcp://127.0.0.1:6379');
// 开启session
session_start();
// 使用session
$_SESSION['sess_name'] = 'test';
$_SESSION['sess_age'] = 20;
var_dump($_SESSION);