<?php
// 通过反射机制查看Redis类的方法
$reflection = new ReflectionClass('Redis');
$methods = $reflection->getMethods();
var_dump($methods);