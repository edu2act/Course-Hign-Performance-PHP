<?php
// 1. 创建Redis对象
$redis = new Redis();
// 2. 建立Redis连接
$redis->connect('127.0.0.1', 6379);
// 3. 操作Redis
$redis->set('name', '张三');
echo $redis->get('name');
// 4. 关闭Redis连接
$redis->close();

