<?php
namespace App\Controllers;

class Person
{
    public function test()
    {
        echo 'test Person';
    }
}