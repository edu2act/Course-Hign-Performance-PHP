<?php
class Tmp
{
    public function test()
    {
        echo 'tmp';
    }
}