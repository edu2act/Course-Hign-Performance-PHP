<?php

function testFun()
{
    echo 'testFun';
}