<?php
trait TestTrait {
 public function testMethod() {
    // 定义时的类名
 echo "Class: " . __CLASS__ . PHP_EOL;
 echo "Trait: " . __TRAIT__ . PHP_EOL;
 }
 }

 class Base 
 {
    use TestTrait;
 }

 class TestBase extends Base
 {

 }

 $obj = new TestBase;
 $obj->testMethod();