<?php
require_once 'vendor/autoload.php';

$p = new \App\Controllers\Person();
// $p->test();

// testFun();
$p = new Tmp();
$p->test();