<?php
	if(!defined('IN_MADM')) exit();	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>No Support For Memcache</title>
<style type="text/css">
body{text-align:center;}
#nomem{margin-top:50px;color:#F00;}
.not{margin-top:10px;}
</style>
</head>

<body>
<div id="nomem">
<div class="not">PHP未安装Memcache扩展</div>
<div class="not">The memcache extension for PHP must be loaded first</div>
</div>
</body>
</html>