<?php
namespace App;

class Cacluate
{
    public function add($x, $y)
    {
        if (is_string($x) && is_string($y)) {
            return $x . $y;
        }
        return $x + $y;
    }
}