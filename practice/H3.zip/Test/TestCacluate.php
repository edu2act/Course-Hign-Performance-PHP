<?php
namespace Test;

class TestCacluate extends \PHPUnit\Framework\TestCase
{
    protected $_obj;    // 测试类对象

    public function setUp()
    {
        $this->_obj = new \App\Cacluate();
    }

    public function testAdd()
    {
        $this->assertEquals($this->_obj->add(3, 4), 7);
    }

    public function testAddString()
    {
        // $obj = new \App\Cacluate();
        $this->assertEquals(
            $this->_obj->add('hello ', 'world'),
            'hello world'
        );
    }
}