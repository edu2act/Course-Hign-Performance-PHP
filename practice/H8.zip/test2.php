<?php
// 1. 建立Memcached连接
$memcache = new Memcache();
$memcache->connect('127.0.0.1', 11211);
// 2. 读取数据库中的数据
// 2.0 数据结果在Memcached中存储的下标？
$sql = 'select * from members';
$key = md5($sql);
// 2.1 首先从Memcached中获取指定数据
$results = $memcache->get($key);
if (!$results) {
    // 2.2 若Memcached中不存在指定数据
    // 2.2.1 从数据库中读取数据
    // $results = $db->query($sql);
    $results = [
        ['name' =>  '张三', 'age' => 18],
        ['name' =>  '李四', 'age' =>  20],
    ];
    // 2.2.2 把数据写入到Memcached中，为下次访问作准备
    $memcache->set($key, $results);
}
// 3. 处理数据
var_dump($results);
// 4. 关闭连接
$memcache->close();