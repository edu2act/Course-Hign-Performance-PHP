<?php
// 1. 建立Memcached连接
$memcache = new Memcache();
$memcache->connect('127.0.0.1', 11211);
// 2. 向Memcached服务器中写入数据
$memcache->add('name', '张三');
$memcache->add('age', 18);
// 3. 获取数据
$name = $memcache->get('name');
echo $name;
// 4. 关闭连接
$memcache->close();