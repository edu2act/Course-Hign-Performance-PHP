<?php
require_once 'MemSession.php';
session_set_save_handler(new MemSession());
// 开启session
session_start();
// 向session中写入数据
$_SESSION['name'] = 'test';
$_SESSION['age'] = 20;
var_dump($_SESSION);